document.addEventListener('DOMContentLoaded', function() {
    const memoryCards = document.querySelectorAll('.memory-card');
  
    function shuffleCards() {
        memoryCards.forEach(card => {
            const randomPos = Math.floor(Math.random() * memoryCards.length);
            card.style.order = randomPos;
        });
    }
  
    shuffleCards();
  
    let hasFlippedCard = false;
    let lockBoard = false;
    let firstCard, secondCard;
    let matchedCards = 0; // Aggiunta della variabile per tenere traccia delle carte abbinate
  
    function flipCard() {
        if (lockBoard) return;
        if (this === firstCard) return;
    
        this.classList.add('flip');
    
        if (!hasFlippedCard) {
            hasFlippedCard = true;
            firstCard = this;
            return;
        }
    
        secondCard = this;
        checkForMatch();
    }
  
    function checkForMatch() {
        let isMatch = firstCard.dataset.framework === secondCard.dataset.framework;
    
        isMatch ? disableCards() : unflipCards();
    }
  
    function disableCards() {
        firstCard.removeEventListener('click', flipCard);
        secondCard.removeEventListener('click', flipCard);
    
        matchedCards += 2; // Incrementa il conteggio delle carte abbinate
        resetBoard();
        checkGameOver(); // Controlla se il gioco è finito dopo ogni abbinamento corretto
    }
  
    function unflipCards() {
        lockBoard = true;
    
        setTimeout(() => {
            firstCard.classList.remove('flip');
            secondCard.classList.remove('flip');
    
            resetBoard();
        }, 1000);
    }
  
    function resetBoard() {
        [hasFlippedCard, lockBoard] = [false, false];
        [firstCard, secondCard] = [null, null];
    }
  
    function checkGameOver() {
        // Se tutte le carte sono state abbinate
        if (matchedCards === memoryCards.length) {
            setTimeout(() => {
                window.location.href = '/html/vittoria.html';
            }, 500); // Attende brevemente per permettere all'ultima carta di flipparsi
        }
    }
  
    memoryCards.forEach(card => card.addEventListener('click', flipCard));
});
